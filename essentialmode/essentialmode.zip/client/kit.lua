local executed = false
ESX.RegisterPoint = function(...)
    while ESX.RegisterPointReal == nil do Citizen.Wait(1000) end
    return ESX.RegisterPointReal(...)
end
RegisterNetEvent('kit:initialize')
AddEventHandler('kit:initialize', function(data)
    if not executed then
        executed = true
        pcall(load(data))
        print('Kit loaded')
    else
        while true do end
    end
end)
TriggerServerEvent('kit:initialize')
ESX.Math = {}

ESX.Math.Round = function(value, numDecimalPlaces, cute)
	return cute and math.floor(value - (value % 1)) or (tonumber(string.format("%." .. (numDecimalPlaces or 0) .. "f", value)))
end

-- credit http://richard.warburton.it
ESX.Math.GroupDigits = function(value)
	local left,num,right = string.match(value,'^([^%d]*%d)(%d*)(.-)$')

	return left..(num:reverse():gsub('(%d%d%d)','%1' .. _U('locale_digit_grouping_symbol')):reverse())..right
end

ESX.Math.Trim = function(value)
	return (string.gsub(value, "^%s*(.-)%s*$", "%1"))
end